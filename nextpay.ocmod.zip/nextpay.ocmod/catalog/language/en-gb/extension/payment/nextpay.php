<?php
// Text
$_['text_title'] 				= 'Secure Payment via NextPay';

$_['heading_fail']				= 'Transaction Failed!';
$_['message_fail']				= '<p>There was a problem with your payment details.</p><p><strong>Your card has not been charged</strong></p><p>Please try again</p>';
